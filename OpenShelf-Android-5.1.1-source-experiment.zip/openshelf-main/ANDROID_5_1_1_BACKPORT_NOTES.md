# Open Shelf Android 5.1.1 compatibility experiment

This is an experimental source backport based on the uploaded `openshelf-main.zip` source tree (versionName 0.11.0 / versionCode 17), NOT the separately uploaded OpenShelf-0.5.0.apk.

Changes:
- minSdk lowered from 23 to 22 (Android 5.1/5.1.1).
- compileSdk set to 35.
- targetSdk lowered from 36 to 28 to avoid requiring modern platform behavior on Android 5.1.
- Android Gradle Plugin downgraded to 8.9.2; Gradle wrapper to 8.11.1.
- Kotlin Compose plugin downgraded to 2.1.20.
- Compose BOM pinned to 2025.03.00, TV Material to 1.0.0, Activity Compose to 1.10.1.
- Core library desugaring pinned to 2.1.4.

Important:
This is NOT a verified Android 5.1.1 APK. It has not been built or run in this environment because an Android SDK installation is not available here. Further dependency/API compatibility fixes may be required after the first Gradle build. In particular, API-23-only runtime calls and library manifest requirements must be checked from build output and on a real API-22 device.
